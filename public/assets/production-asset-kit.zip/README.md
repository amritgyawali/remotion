# Remotion Production Asset Kit

This archive contains 41 original editable SVG visuals, 3 loopable music beds, and 10 sound effects.

## Install

Extract the contents of this archive into your Remotion project public/assets directory. The existing visual/ and audio/ paths are preserved.

Use assets without the public/ prefix:

    staticFile('assets/visual/v1/objects/phone.svg')
    staticFile('assets/audio/v1/music/neon-pulse-120bpm-loop.wav')

- catalog.json is the combined machine-readable catalog.
- visual/v1/catalog.json and audio/catalog.json contain pack-specific metadata.
- index.html is the searchable visual and audio gallery.
- The generated assets are CC0-1.0 and require no attribution.
